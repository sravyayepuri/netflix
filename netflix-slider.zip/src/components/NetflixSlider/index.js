import Slider from './Slider'
import Item from './Item'

Slider.Item = Item;

export default Slider;
