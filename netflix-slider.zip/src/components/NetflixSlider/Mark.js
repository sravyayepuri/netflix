import React from 'react'
import './Mark.scss'

const Mark = () => (<div className="mark" />)

export default Mark;
